import './custom-js/global'
import '#template/js/'
import './custom-js/pages'
