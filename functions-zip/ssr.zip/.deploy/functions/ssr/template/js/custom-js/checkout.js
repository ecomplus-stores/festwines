window.propsShippingCalculator = {
  canAutoSelectService: false
}
